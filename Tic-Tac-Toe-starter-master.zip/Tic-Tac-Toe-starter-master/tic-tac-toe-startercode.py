class Game:
    # Represents the visual representation of the game
    board_layout = """
___________________
|     |     |     |
|  7  |  8  |  9  |
|     |     |     |
|-----------------|
|     |     |     |
|  4  |  5  |  6  |
|     |     |     |
|-----------------|
|     |     |     |
|  1  |  2  |  3  |
|     |     |     |
|-----------------|
"""
    # Represents the list model of the game. (abstract)
    board = ['#', '#', '#', '#', '#', '#', '#', '#', '#', '#']
